import time
from datetime import datetime
from airflow.models.dag import DAG
from airflow.decorators import task
from airflow.utils.task_group import TaskGroup
from airflow.providers.mysql.hooks.mysql import MySqlHook
from airflow.hooks.base import BaseHook
# from standardata import standardiser as sd
import pandas as pd
from sqlalchemy import create_engine

#Extract airflow tasks
@task()
def get_src_tables():
    hook = MySqlHook(mysql_conn_id="mysql")
    mysql_query = """SELECT table_name AS 't.name' FROM information_schema.TABLES AS t WHERE t.table_name IN ('Production_Product', 'Production_ProductSubcategory', 'Production_ProductCategory','Sales_SalesTerritory');"""
    df = hook.get_pandas_df(mysql_query)
    tbl_dict = df.to_dict()
    return tbl_dict


#Load to Postgres
@task()
def load_src_tables(tbl_dict: dict):
    conn = BaseHook.get_connection('postgres')
    engine = create_engine(f'postgresql://{conn.login}:{conn.password}@{conn.host}:{conn.port}/{conn.schema}')
    all_tbl_name = []
    start_time = time.time()
    
    #Access table_name element in dictionaries
    for k,v in tbl_dict['t.name'].items():
        all_tbl_name.append(v)
        rows_imported = 0
        mysql_query = f'SELECT * FROM {v}'
        hook = MySqlHook(mysql_conn_id="mysql")
        df = hook.get_pandas_df(mysql_query)
        print(f"Importing Rows {rows_imported} to {rows_imported + len(df)}... for table {v}")
        df.to_sql(f'src_{v}', engine, if_exists='replace', index=False)
        rows_imported += len(df)
        print(f"Done. {str(round(time.time() - start_time, 2))} total seconds elapsed.")
    print("Data imported successfully.")
    return all_tbl_name


#Transform data
@task()
def transform_srcProduct():
    conn = BaseHook.get_connection('postgres')
    engine = create_engine(f'postgresql://{conn.login}:{conn.password}@{conn.host}:{conn.port}/{conn.schema}')
    pdf = pd.read_sql_query('SELECT * FROM public."src_Production_Product"', engine)
    
    #Drop null columns 
    df_revised = pdf[['ProductID', 'Name', 'ProductNumber', 'MakeFlag', 'FinishedGoodsFlag', 'Color', 'SafetyStockLevel', 'ReorderPoint', 'StandardCost', 'ListPrice', 'Size', 'SizeUnitMeasureCode', 'WeightUnitMeasureCode', 'DaysToManufacture', 'ProductSubcategoryID', 'ProductModelID', 'SellStartDate', 'SellEndDate', 'rowguid', 'ModifiedDate']]
    
    #Replace and standardise null data
    # df_revised = sd.standardiser().batch_mkstd(df_revised, ['ProductID', 'Name', 'ProductNumber', 'MakeFlag', 'FinishedGoodsFlag', 'Color', 'SafetyStockLevel', 'ReorderPoint', 'StandardCost', 'ListPrice', 'Size', 'SizeUnitMeasureCode', 'WeightUnitMeasureCode', 'DaysToManufacture', 'ProductSubcategoryID', 'ProductModelID', 'SellStartDate', 'SellEndDate', 'rowguid', 'ModifiedDate'])

    df_revised['ProductID'].fillna('0', inplace=True)
    df_revised['Name'].fillna('N/A', inplace=True)
    df_revised['ProductNumber'].fillna('0', inplace=True)
    df_revised['MakeFlag'].fillna('0', inplace=True)
    df_revised['FinishedGoodsFlag'].fillna('0', inplace=True)
    df_revised['Color'].fillna('N/A', inplace=True)
    df_revised['SafetyStockLevel'].fillna('0', inplace=True)
    df_revised['ReorderPoint'].fillna('0', inplace=True)
    df_revised['StandardCost'].fillna('0', inplace=True)
    df_revised['ListPrice'].fillna('0', inplace=True)
    df_revised['Size'].fillna('0', inplace=True)
    df_revised['SizeUnitMeasureCode'].fillna('N/A', inplace=True)
    df_revised['WeightUnitMeasureCode'].fillna('N/A', inplace=True)
    df_revised['DaysToManufacture'].fillna('0', inplace=True)
    df_revised['ProductSubcategoryID'].fillna('0',inplace=True)
    df_revised['ProductModelID'].fillna('0', inplace=True)
    df_revised['SellStartDate'].fillna('N/A', inplace=True)
    df_revised['SellEndDate'].fillna('N/A', inplace=True)
    df_revised['rowguid'].fillna('N/A', inplace=True)
    df_revised['ModifiedDate'].fillna('N/A', inplace=True)

    #Rename column
    df_revised = df_revised.rename(columns={"rowguid": "ROWGUID"})

    #Save to staging table
    df_revised.to_sql(f'stg_Production_Product', engine, if_exists='replace', index=False)
    return{"table(s) processed ": "Data imported successfully."}


#Transformation task 2
@task()
def transform_srcSubcategory():
    conn = BaseHook.get_connection('postgres')
    engine = create_engine(f'postgresql://{conn.login}:{conn.password}@{conn.host}:{conn.port}/{conn.schema}')
    pdf = pd.read_sql_query('SELECT * FROM public."src_Production_ProductSubcategory"', engine)

    #Replace and standardise null data
    df_revised = pdf
    df_revised['ProductSubcategoryID'].fillna('N/A', inplace=True)
    df_revised['ProductCategoryID'].fillna('N/A', inplace=True)
    df_revised['Name'].fillna('N/A', inplace=True)
    df_revised['rowguid'].fillna('N/A', inplace=True)
    df_revised['ModifiedDate'].fillna('N/A', inplace=True)

    #Rename column
    df_revised = df_revised.rename(columns={"rowguid": "ROWGUID"})

    #Save to staging table
    df_revised.to_sql(f'stg_Production_ProductSubcategory', engine, if_exists='replace', index=False)
    return{"table(s) processed ": "Data imported successfully."}


#Transform task 3
@task()
def transform_srcCategory():
    conn = BaseHook.get_connection('postgres')
    engine = create_engine(f'postgresql://{conn.login}:{conn.password}@{conn.host}:{conn.port}/{conn.schema}')
    pdf = pd.read_sql_query('SELECT * FROM public."src_Production_ProductCategory"', engine)

    #Replace and standardise null data
    df_revised = pdf
    df_revised['ProductCategoryID'].fillna('N/A', inplace=True)
    df_revised['Name'].fillna('N/A', inplace=True)
    df_revised['rowguid'].fillna('N/A', inplace=True)
    df_revised['ModifiedDate'].fillna('N/A', inplace=True)

    #Rename column
    df_revised = df_revised.rename(columns={"rowguid": "ROWGUID"})

    #Save to staging table
    df_revised.to_sql(f'stg_Production_ProductCategory', engine, if_exists='replace', index=False)
    return{"table(s) processed ": "Data imported successfully."}


#Load
@task()
def prdProduct_model():
    conn = BaseHook.get_connection('postgres')
    engine = create_engine(f'postgresql://{conn.login}:{conn.password}@{conn.host}:{conn.port}/{conn.schema}')
    prod = pd.read_sql_query('SELECT * FROM public."stg_Production_Product"', engine)
    prod_cat = pd.read_sql_query('SELECT * FROM public."stg_Production_ProductCategory"', engine)
    prod['ProductSubcategoryID'] = prod.ProductSubcategoryID.astype(float)
    prod['ProductSubcategoryID'] = prod.ProductSubcategoryID.astype(int)
    prod_sub = pd.read_sql_query('SELECT * FROM public."stg_Production_ProductSubcategory"', engine)

    #Merge all tables into single dataframe
    df_merged = prod.merge(prod_sub, on='ProductSubcategoryID').merge(prod_cat, on='ProductCategoryID')
    df_merged.to_sql(f'prd_Production_Product', engine, if_exists='replace', index=False)
    return{"table(s) processed ": "Data imported successfully."}

#[START how_to_task_group]
with DAG(dag_id="product_etl_dag", schedule_interval="0 9 * * *", start_date=datetime(2024,1,30), catchup=False, tags=["product_model"]) as dag:
    
    with TaskGroup("extract_Production_Product_load", tooltip="Extract and load source data") as extract_load_src:
        src_product_tbls = get_src_tables()
        load_Production_Products = load_src_tables(src_product_tbls)
        #Define order
        src_product_tbls >> load_Production_Products

    # [START how_to_task_group_section2]
    with TaskGroup("transform_src_product", tooltip="Transform and stage data") as transform_src_product:
        transform_srcProduct = transform_srcProduct()
        transform_srcSubcategory = transform_srcSubcategory()
        transform_srcCategory = transform_srcCategory()
        #Define order
        [transform_srcProduct, transform_srcSubcategory, transform_srcCategory]

    with TaskGroup("load_product_model", tooltip="Final product model") as load_product_model:
        prd_Product_model = prdProduct_model()
        #Define order
        prd_Product_model
        
    extract_load_src >> transform_src_product >> load_product_model