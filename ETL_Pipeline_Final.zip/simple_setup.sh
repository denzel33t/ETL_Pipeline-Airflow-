mkdir airflow_mysql
mv etl_airflow.py ./airflow_mysql
mv docker-compose.yaml ./airflow_mysql
mv Dockerfile ./airflow_mysql
cd airflow_mysql
mkdir ./dags ./logs ./plugins
mv etl_airflow.py ./dags

