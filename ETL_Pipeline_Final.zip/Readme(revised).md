The instructions for this Apache Airflow Pipeline is intended for a **MacOS environment**.

## Create an Airflow directory
Run the simple_setup.sh bash script; this will create your airflow directory, with the files in the right place already.
(Open the folder containing the script in a Terminal, and enter "sh ./simple_setup.sh")

## Setting Up Your Database(s)
Download the latest version of MySQL and PostgreSQL (if you don't already have it).
Download the AdventureWorks schema from the link below (this will be our dummy data): 
https://drive.google.com/file/d/1El2k-pl1vLhX0_fv03raUSHEcVP_H7Yn/view?usp=sharing
    
# MySQL Setup
- Create a new database called "SampleData" and use it
- In the navigation bar, select 'Server'-->'Data Import'
- In the import menu, select 'Import from self contained file' and select the "AdventureWorks2019.sql" file, 
- Select the 'Default Target Schema' as SampleData, then start import
- You should now have the AdventureWorks2019 schema within your SampleData database
- Create a new user called 'etl' with the password 'password'
- Grant the etl user the following Global Privileges: "SELECT, SHOW DATABASES, SHOW VIEW"
- Grant the etl user the following Schema Privileges for the SampleData database: "SELECT, SHOW VIEW"

# PostgreSQL setup
- Create a new database called "AdventureWorks"
- Create a new user called 'etl' using the following script, to give it the necessary privileges:
    CREATE USER 'etl' WITH PASSWORD 'password';
    GRANT CONNECT ON DATABASE "AdventureWorks" TO etl;
    GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO etl;

## Installing necessary Python Packages
Depending on which Python distribution you are using, you may have some of the packages already (for example 'Pandas' if you are using Anaconda like myself), the rest will need to be installed. If you do not wish to install these packages on your base environment, you can install them inside a virtual environment instead. To make things easier, it is recommended to open the DAG file in VS Code, and use the Python Terminal there for installations.**NOTE**:*If you choose to install the packages within a virtual environment, it will require extra steps using the Apache Airflow PythonOperator to get the ETL pipeline working. I have not tried that myself, as such I recommend installing the packages in your base directory and then removing them after.*

Install Pandas:
- Enter the following in your VS Code terminal:
    pip install pandas

Install SQLalchemy:
- Enter the following in your VS Code terminal:
    pip install sqlalchemy

Install Apache Airflow:
- Enter the following in your VS Code terminal:
    pip install apache-airflow

Install Apache Airflow MySQL provider:
- Enter the follwing in your VS Code terminal:
    pip install apache-airflow-providers-mysql

## Build Docker image and run containers
- Open Docker Desktop
- Open a new terminal inside your "airflow_mysql" folder
- Enter the following in the Terminal:
    docker build -t airflow_mysql -f Dockerfile . --no-cache
- After the image builds successfully, run the following command:
    docker compose up -d
- This will run your containers in detached mode so you still have free use of the terminal

## Running ETL pipeline
- Open a new tab in your preferred browser (I like to use Brave)
- Enter the following in your address bar: localhost:9090
- Enter 'airflow' as your username and password
# Creating MySQL and Postgres connections
MySQL Connection
- Open the dropwdown list in the 'Admin' tab and click on 'Connections'
- Click on the blue plus sign to add a new record
- In 'Connection Id' enter 'mysql'
- For 'Connection Type' select MySQL
- In 'Host' enter your IP address E.g 173.168.1.88 (Not my actual IP address, don't worry)
- For the schema enter 'SampleData'
- In the login box enter 'etl'
- For the password enter 'password'
- Enter '3306' for the 'Port' (default MySQL port number) 
- Test the connection, you should get a success message

PostgreSQL Connection
- In 'Connection Id' enter 'postgres'
- For 'Connection Type' select Postgres
- In 'Host' enter your IP address
- For the database enter 'AdventureWorks'
- In the login box enter 'etl'
- For the password enter 'password'
- Enter 5432 for the 'Port' (default Postgers port number)
- Test the connection, you should get a success message

Run the DAG
- Go to your list of DAGs by clicking 'DAGs' in the navigation menu
- Scroll down until you find 'product_etl_dag' and toggle the switch to unpause the DAG
- Run the DAG by pressing the play button on the right-hand side
- If everything has worked up until this point, you will see a message: "Triggered product_etl_dag, it should start any moment now."
- Open pgAdmin 4 and refresh your AdventureWorks database
- You will see there are now 8 tables: 4 source tables, 3 staging tables and 1 final 'production-ready' table

You now have a running Apache Airflow ETL pipeline!

*If you look at the code inside the etl_airflow.py script, you will notice there is a commented-out import and block of code (around line 55 depending on which IDE you're using). This was a class I created to make the code more clean and avoid code redundancy through repeating lines; however, a problem I encountered was that I was unable to get this module into my Python Path so that Airflow could pick it up and use it. I tried circumventing this using Watchman but found the problem persisted, hence I opted to do without it, in the interest of geting the pipeline to work.*

!----------------------------------------------------------------------------------------------------------------------------------------!
## Opening connections (ONLY IF NECESSARY - DO NOT DO THIS UNLESS APACHE AIRFLOW CANNOT CONNECT TO POSTGRES AT ALL)
These changes should ONLY be made on a personal device and advisably **NOT** on a company machine.
Before any changes are made, make a copy of the original postgresql.conf and pg_hba.conf file.
Once you have got the pipeline working and are satisfied, you may restore the original files.
Note that if you want to run the pipeline again, you may have to change the pg_hba.conf and postgresql.conf files again.

# Edit your postgresql.conf file
- Open Postgres (Not pgAdmin 4, but the Postgres manager application)
- Select "Server Settings" and then select "Show" on Config File
- Open postgresql.conf with your preferred text editor
- Scroll down to the section titled "CONNECTIONS AND AUTHENTICATION"
- Underneath "Connection Settings", uncomment the line "listen_addresses", and after the equals symbol put '*'
- It should look like this: listen_addresses = '*'		# what IP address(es) to listen on;

# Edit your pg_hba.conf file 
- Open Postgres (Not pgAdmin 4, but the Postgres manager application)
- Select "Server Settings" and then select "Show" on HBA File
- Open 'pg_hba.conf' with your preferred text editor
- Go down to your list of connections, denoted by the sections 'TYPE, DATABASE, USER, ADDRESS, METHOD'
- Add the following lines directly beneath the aforementioned section headers:
    host    all             all             *"First three digits of your IP address".0.0.0/0             scram-sha-256
    host    all             all             ::1/128                 scram-sha-256
    host    all             postgres        127.0.0.1/32            trust
*For example, if your IP address was 173.168.1.88, you would put 173.0.0.0/0, allowing all connections from your IP address only
- Under IPv4 local connections add:
    host    all             all             0.0.0.0/0             trust
- Under IPv6 local connections add:
    host    all             all             0.0.0.0/0             trust
- Finally, under the section beginning "Allow replication connections from localhost" add:
    local   replication     all                                     trust
    host    replication     all             127.0.0.1/32            trust
    host    replication     all             ::1/128                 trust

After editing both files, you will need to restart your Postgres server for the changes to take efffect, before attempting to run the pipeline again.    